import java.util.ArrayList;
import java.util.Scanner;
class Student {
    private int id;
    private String name;
    private String email;
    private String phone;
    private String department;
    private double tuitionFee;
    private double feePaid;
    public Student(int id, String name, String email, String phone, String department){
        this.id=id;
        this.name=name;
        this.email=email;
        this.phone=phone;
        this.department=department;
        this.tuitionFee=0;
        this.feePaid=0;
    }
    public int getId(){
        return id;
    }
    public String getName(){
        return name;
    }
    public String getEmail(){
        return email;
    }
    public String getPhone(){
        return phone;
    }
    public String getDepartment(){
        return department;
    }
    public double getTuitionFee(){
        return tuitionFee;
    }
    public double getFeePaid(){
        return feePaid;
    }
    public double getDueAmount(){
        return tuitionFee - feePaid;
    }
    public void setTuitionFee(double fee){
        this.tuitionFee=fee;
    }
    public void payFee(double amount){
        this.feePaid+=amount;
    }
    public String toString(){
        return String.format("ID: %d\nName; %s\nEmail: %s\nPhone: %s\nDepartment: %s\nTuition Fee: %2f\nFee Paid: %.2f\nDue Amount: %.2f",id, name, email, phone, department, tuitionFee, feePaid, getDueAmount());

    }

}
class Exam{
    private int examId;
    private String examName;
    private String examDate;
    private ArrayList<Integer> studentIds;
    private ArrayList<Double> marks;

    public Exam(int examId, String examName, String examDate){
        this.examId=examId;
        this.examName=examName;
        this.studentIds=new ArrayList<>();
        this.marks=new ArrayList<>();
    }

    public int getExamId(){
        return examId;
    }
    public String getExamName(){
        return examName;
    }
    public String getExamDate(){
        return examDate;
    }

    public void addStudentMark(int studentId, double mark){
        studentIds.add(studentId);
        marks.add(mark);
    }

     public Double getStudentMark(int studentId){
        for(int i=0; i< studentIds.size(); i++){
            if(studentIds.get(i) == studentId){
                return marks.get(i);
            }
        }
        return null;
     }

     public String toString(){
        return String.format("Exam ID: %d\nExam Name: %s\nDate: %s\nNumber of Students: %d",
                examId, examName, examDate, studentIds.size());
     }
}

public class StudentManagementSystem{
     private static ArrayList<Student> students = new ArrayList<>();
    private static ArrayList<Exam> exams = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);
    private static int nextStudentId = 1;
    private static int nextExamId = 1;

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n=== Student Management System ===");
            System.out.println("1. Student Management");
            System.out.println("2. Exam Management");
            System.out.println("3. Tuition Fee Management");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
                continue;
            }

            switch (choice) {
                case 1:
                    studentManagement();
                    break;
                case 2:
                    examManagement();
                    break;
                case 3:
                    feeManagement();
                    break;
                case 4:
                    System.out.println("Exiting the system. Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void studentManagement() {
        while (true) {
            System.out.println("\n=== Student Management ===");
            System.out.println("1. Add New Student");
            System.out.println("2. View All Students");
            System.out.println("3. View Student Details");
            System.out.println("4. Update Student");
            System.out.println("5. Delete Student");
            System.out.println("6. Back to Main Menu");
            System.out.print("Enter your choice: ");

            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
                continue;
            }

            switch (choice) {
                case 1:
                    addStudent();
                    break;
                case 2:
                    viewAllStudents();
                    break;
                case 3:
                    viewStudentDetails();
                    break;
                case 4:
                    updateStudent();
                    break;
                case 5:
                    deleteStudent();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addStudent() {
        System.out.println("\n--- Add New Student ---");
        
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        
        System.out.print("Enter phone: ");
        String phone = scanner.nextLine();
        
        System.out.print("Enter department: ");
        String department = scanner.nextLine();
        
        Student student = new Student(nextStudentId++, name, email, phone, department);
        students.add(student);
        
        System.out.println("Student added successfully with ID: " + student.getId());
    }

    private static void viewAllStudents() {
        System.out.println("\n--- All Students ---");
        if (students.isEmpty()) {
            System.out.println("No students found.");
            return;
        }
        
        for (Student student : students) {
            System.out.println("ID: " + student.getId() + ", Name: " + student.getName() + 
                             ", Department: " + student.getDepartment());
            System.out.println("--------------------------------");
        }
    }

    private static void viewStudentDetails() {
        System.out.print("\nEnter student ID: ");
        int id;
        try {
            id = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID format.");
            return;
        }
        
        Student student = findStudentById(id);
        if (student != null) {
            System.out.println("\n--- Student Details ---");
            System.out.println(student);
        } else {
            System.out.println("Student not found with ID: " + id);
        }
    }

    private static void updateStudent() {
        System.out.print("\nEnter student ID to update: ");
        int id;
        try {
            id = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID format.");
            return;
        }
        
        Student student = findStudentById(id);
        if (student == null) {
            System.out.println("Student not found with ID: " + id);
            return;
        }
        
        System.out.println("\nCurrent Details:");
        System.out.println(student);
        
        System.out.println("\nEnter new details (leave blank to keep current value):");
        
        System.out.print("Name [" + student.getName() + "]: ");
        String name = scanner.nextLine();
        if (!name.isEmpty()) {
            // In a real system, we would have a setName method
            // For this example, we'll create a new student object
            student = new Student(student.getId(), name, student.getEmail(), 
                                student.getPhone(), student.getDepartment());
            updateStudentInList(student);
        }
        
        System.out.print("Email [" + student.getEmail() + "]: ");
        String email = scanner.nextLine();
        if (!email.isEmpty()) {
            student = new Student(student.getId(), student.getName(), email, 
                                student.getPhone(), student.getDepartment());
            updateStudentInList(student);
        }
        
        System.out.print("Phone [" + student.getPhone() + "]: ");
        String phone = scanner.nextLine();
        if (!phone.isEmpty()) {
            student = new Student(student.getId(), student.getName(), student.getEmail(), 
                                phone, student.getDepartment());
            updateStudentInList(student);
        }
        
        System.out.print("Department [" + student.getDepartment() + "]: ");
        String department = scanner.nextLine();
        if (!department.isEmpty()) {
            student = new Student(student.getId(), student.getName(), student.getEmail(), 
                                student.getPhone(), department);
            updateStudentInList(student);
        }
        
        System.out.println("Student updated successfully!");
    }

    private static void deleteStudent() {
        System.out.print("\nEnter student ID to delete: ");
        int id;
        try {
            id = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID format.");
            return;
        }
        
        Student student = findStudentById(id);
        if (student == null) {
            System.out.println("Student not found with ID: " + id);
            return;
        }
        
        System.out.println("\nStudent to delete:");
        System.out.println(student);
        
        System.out.print("Are you sure you want to delete this student? (yes/no): ");
        String confirmation = scanner.nextLine();
        
        if (confirmation.equalsIgnoreCase("yes")) {
            students.remove(student);
            System.out.println("Student deleted successfully!");
        } else {
            System.out.println("Deletion cancelled.");
        }
    }
    private static void examManagement() {
        while (true) {
            System.out.println("\n=== Exam Management ===");
            System.out.println("1. Create New Exam");
            System.out.println("2. View All Exams");
            System.out.println("3. Add Exam Marks");
            System.out.println("4. View Exam Results");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");

            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
                continue;
            }

            switch (choice) {
                case 1:
                    createExam();
                    break;
                case 2:
                    viewAllExams();
                    break;
                case 3:
                    addExamMarks();
                    break;
                case 4:
                    viewExamResults();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void createExam() {
        System.out.println("\n--- Create New Exam ---");
        
        System.out.print("Enter exam name: ");
        String name = scanner.nextLine();
        
        System.out.print("Enter exam date (DD/MM/YYYY): ");
        String date = scanner.nextLine();
        
        Exam exam = new Exam(nextExamId++, name, date);
        exams.add(exam);
        
        System.out.println("Exam created successfully with ID: " + exam.getExamId());
    }

    private static void viewAllExams() {
        System.out.println("\n--- All Exams ---");
        if (exams.isEmpty()) {
            System.out.println("No exams found.");
            return;
        }
        
        for (Exam exam : exams) {
            System.out.println(exam);
            System.out.println("--------------------------------");
        }
    }

    private static void addExamMarks() {
        System.out.print("\nEnter exam ID: ");
        int examId;
        try {
            examId = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID format.");
            return;
        }
        
        Exam exam = findExamById(examId);
        if (exam == null) {
            System.out.println("Exam not found with ID: " + examId);
            return;
        }
        
        System.out.print("Enter student ID: ");
        int studentId;
        try {
            studentId = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID format.");
            return;
        }
        
        Student student = findStudentById(studentId);
        if (student == null) {
            System.out.println("Student not found with ID: " + studentId);
            return;
        }
        
        System.out.print("Enter marks for " + student.getName() + ": ");
        double marks;
        try {
            marks = Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid marks format.");
            return;
        }
        
        exam.addStudentMark(studentId, marks);
        System.out.println("Marks added successfully!");
    }

    private static void viewExamResults() {
        System.out.print("\nEnter exam ID: ");
        int examId;
        try {
            examId = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID format.");
            return;
        }
        
        Exam exam = findExamById(examId);
        if (exam == null) {
            System.out.println("Exam not found with ID: " + examId);
            return;
        }
        
        System.out.println("\n--- Exam Results for " + exam.getExamName() + " ---");
        for (Student student : students) {
            Double marks = exam.getStudentMark(student.getId());
            if (marks != null) {
                System.out.println("Student ID: " + student.getId() + 
                                 ", Name: " + student.getName() + 
                                 ", Marks: " + marks);
            }
        }
    }

    private static void feeManagement() {
        while (true) {
            System.out.println("\n=== Tuition Fee Management ===");
            System.out.println("1. Set Tuition Fee");
            System.out.println("2. Record Fee Payment");
            System.out.println("3. View Fee Status");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter your choice: ");

            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
                continue;
            }

            switch (choice) {
                case 1:
                    setTuitionFee();
                    break;
                case 2:
                    recordFeePayment();
                    break;
                case 3:
                    viewFeeStatus();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void setTuitionFee() {
        System.out.print("\nEnter student ID: ");
        int studentId;
        try {
            studentId = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID format.");
            return;
        }
        
        Student student = findStudentById(studentId);
        if (student == null) {
            System.out.println("Student not found with ID: " + studentId);
            return;
        }
        
        System.out.print("Enter tuition fee amount: ");
        double fee;
        try {
            fee = Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid amount format.");
            return;
        }
        
        student.setTuitionFee(fee);
        System.out.println("Tuition fee set successfully!");
    }

    private static void recordFeePayment() {
        System.out.print("\nEnter student ID: ");
        int studentId;
        try {
            studentId = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID format.");
            return;
        }
        
        Student student = findStudentById(studentId);
        if (student == null) {
            System.out.println("Student not found with ID: " + studentId);
            return;
        }
        
        System.out.print("Enter payment amount: ");
        double amount;
        try {
            amount = Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid amount format.");
            return;
        }
        
        student.payFee(amount);
        System.out.println("Payment recorded successfully!");
        System.out.println("Total fee paid: " + student.getFeePaid());
        System.out.println("Due amount: " + student.getDueAmount());
    }

    private static void viewFeeStatus() {
        System.out.print("\nEnter student ID: ");
        int studentId;
        try {
            studentId = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID format.");
            return;
        }
        
        Student student = findStudentById(studentId);
        if (student == null) {
            System.out.println("Student not found with ID: " + studentId);
            return;
        }
        
        System.out.println("\n--- Fee Status ---");
        System.out.println("Student ID: " + student.getId());
        System.out.println("Name: " + student.getName());
        System.out.println("Tuition Fee: " + student.getTuitionFee());
        System.out.println("Fee Paid: " + student.getFeePaid());
        System.out.println("Due Amount: " + student.getDueAmount());
    }

    // Helper methods
    private static Student findStudentById(int id) {
        for (Student student : students) {
            if (student.getId() == id) {
                return student;
            }
        }
        return null;
    }

    private static Exam findExamById(int id) {
        for (Exam exam : exams) {
            if (exam.getExamId() == id) {
                return exam;
            }
        }
        return null;
    }

    private static void updateStudentInList(Student updatedStudent) {
        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getId() == updatedStudent.getId()) {
                students.set(i, updatedStudent);
                return;
            }
        }
    }
}





